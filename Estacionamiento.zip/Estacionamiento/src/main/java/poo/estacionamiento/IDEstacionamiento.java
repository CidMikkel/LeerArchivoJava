/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package poo.estacionamiento;

/**
 *
 * @author Mikkel Paz
 */
import javax.swing.table.DefaultTableModel;
import poo.estacionamiento.Estacionamiento;

public interface IDEstacionamiento {
    
    public void Guardar(Estacionamiento estacionamiento);
    public DefaultTableModel listar();   
    
    
}
