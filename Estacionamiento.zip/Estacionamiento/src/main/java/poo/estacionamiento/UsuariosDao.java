/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.estacionamiento;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Mikkel Paz
 */
public class UsuariosDao extends User{
    
    public boolean leerArchivo(String usuario, String contraseña){
        boolean resp = false;
        
        try{ 
            FileReader fr = new FileReader("Usuario.txt");
            BufferedReader br = new BufferedReader(fr);
            String d ="";
            
            while((d=br.readLine())!= null){
                StringTokenizer unaLinea = new StringTokenizer(d,"|");
                Vector x = new Vector();
                
                while(unaLinea.hasMoreTokens()){
                    String usu = unaLinea.nextToken();
                    String contra = unaLinea.nextToken();
                    if(usuario.equals(usu)&& contraseña.equals(contra)){
                        resp = true;
                        JOptionPane.showMessageDialog(null, "Bienvenido");
                        
                    }else {
                        JOptionPane.showMessageDialog(null, "Usuario o Contraseña Incorrectos");
                    }
                }
            }  
        }catch(java.io.IOException ioex){
            JOptionPane.showMessageDialog(null, ioex.toString());
        }
        return resp;
    }
    
    
    
}
