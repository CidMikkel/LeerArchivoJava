/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.estacionamiento;


import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mikkel Paz
 */
public class EstacionamientoDao 
        extends Estacionamiento 
        implements IDEstacionamiento {

    
    
    Vector Vestacionamiento = new Vector();
    
    @Override
    public void Guardar(Estacionamiento estacionamiento) {
        Vestacionamiento.addElement(estacionamiento);
        
    }

    @Override
    public DefaultTableModel listar() {
        Vector vCabe = new Vector();
        vCabe.addElement("Marca");
        vCabe.addElement("Modelo");
        vCabe.addElement("Color");
        vCabe.addElement("Matricula");
        vCabe.addElement("Fecha");
        DefaultTableModel mdTable = new DefaultTableModel(vCabe,0);
        try{
            FileReader fw = new FileReader("Estacionamiento.txt");
            BufferedReader br = new BufferedReader(fw);
            String d ;
            while((d=br.readLine())!= null){
               StringTokenizer linea = new StringTokenizer(d,",");
                Vector x = new Vector();
                while(linea.hasMoreTokens()){
                    x.addElement(linea.nextToken());
                } 
                mdTable.addRow(x);
            }
                
                
                
        }catch(java.io.IOException ioex){
            JOptionPane.showMessageDialog(null, ioex.toString());
        }
        return mdTable;
       }
    public void GuardarArchivo(Estacionamiento estacionamiento){
        
        try{
            
            FileWriter fw = new FileWriter("Estacionamiento.txt",true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            pw.print(estacionamiento.getMarca());
            pw.print(","+estacionamiento.getModelo());
            pw.print(","+estacionamiento.getColor());
            pw.print(","+estacionamiento.getMatricula());
            pw.println(","+estacionamiento.getFecha());
            pw.close();
            
        }catch(java.io.IOException ioex){
            JOptionPane.showMessageDialog(null, ioex.toString());
        
    }
        
    }
    
}
