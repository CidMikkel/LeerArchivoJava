/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.estacionamiento;

/**
 *
 * @author Mikkel Paz
 */
public class User {
    private String nom_user;
    private String contraseña;

    public User() {
    }

    public User(String nom_user, String contraseña) {
        this.nom_user = nom_user;
        this.contraseña = contraseña;
    }

    public String getNom_user() {
        return nom_user;
    }

    public void setNom_user(String nom_user) {
        this.nom_user = nom_user;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
    
}
