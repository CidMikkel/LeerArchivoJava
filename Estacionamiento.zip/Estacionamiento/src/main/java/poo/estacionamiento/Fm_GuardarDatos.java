/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package poo.estacionamiento;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Mikkel Paz
 */
public class Fm_GuardarDatos extends javax.swing.JFrame {

    EstacionamientoDao estacionamientoDao = new EstacionamientoDao();
    Estacionamiento estacionamiento = new Estacionamiento();
    
    public void activaDesactiva(boolean accion){
        txt_Marca.setEditable(accion);
        txt_Modelo.setEditable(accion);
        txt_Color.setEditable(accion);
        txt_Matricula.setEditable(accion);
        txt_Fecha.setEditable(accion);
        txt_Marca.requestFocus();
        
    }
    public void limpiar(){
        txt_Marca.setText("");
        txt_Modelo.setText("");
        txt_Color.setText("");
        txt_Matricula.setText("");
        txt_Fecha.setText("");
        txt_Marca.requestFocus();
    }
    
    public Fm_GuardarDatos() {
        initComponents();
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Marca = new javax.swing.JLabel();
        Modelo = new javax.swing.JLabel();
        Color = new javax.swing.JLabel();
        Matricula = new javax.swing.JLabel();
        Fecha = new javax.swing.JLabel();
        txt_Color = new javax.swing.JTextField();
        txt_Matricula = new javax.swing.JTextField();
        txt_Fecha = new javax.swing.JTextField();
        txt_Marca = new javax.swing.JTextField();
        txt_Modelo = new javax.swing.JTextField();
        Guardar = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        btn_Listar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Marca.setText("Marca");

        Modelo.setText("Modelo");

        Color.setText("Color");

        Matricula.setText("Matricula");

        Fecha.setText("Fecha");

        Guardar.setText("Guardar");
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });

        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });

        btn_Listar.setText("Listar Datos");
        btn_Listar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ListarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Guardar)
                        .addGap(83, 83, 83)
                        .addComponent(btn_Listar)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Fecha)
                            .addComponent(Matricula)
                            .addComponent(Color)
                            .addComponent(Modelo)
                            .addComponent(Marca))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_Marca)
                            .addComponent(txt_Modelo)
                            .addComponent(txt_Color)
                            .addComponent(txt_Matricula)
                            .addComponent(txt_Fecha, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                        .addGap(185, 185, 185))))
            .addGroup(layout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addComponent(Salir)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Marca)
                    .addComponent(txt_Marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Modelo)
                    .addComponent(txt_Modelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Color)
                    .addComponent(txt_Color, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Matricula)
                    .addComponent(txt_Matricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Fecha)
                    .addComponent(txt_Fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Guardar)
                    .addComponent(btn_Listar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(Salir)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
     if(Guardar.getText().equalsIgnoreCase("Guardar")){
       activaDesactiva(true);  
       Guardar.setText("Guarda");
     }else {
         if(txt_Marca.getText().equalsIgnoreCase("")
             ||txt_Modelo.getText().equalsIgnoreCase("")
             ||txt_Color.getText().equalsIgnoreCase("")
             ||txt_Matricula.getText().equalsIgnoreCase("")
             ||txt_Fecha.getText().equalsIgnoreCase("")){
         JOptionPane.showMessageDialog(null,"TODOS LOS CAMPOS DEBEN ESTAR LLENOS");
         }else{
            estacionamiento.setMarca(txt_Marca.getText());
            estacionamiento.setModelo(txt_Modelo.getText());
            estacionamiento.setColor(txt_Color.getText());
            estacionamiento.setMatricula(txt_Matricula.getText());
            estacionamiento.setFecha(txt_Fecha.getText());
     
            estacionamientoDao.Guardar(estacionamiento);
            estacionamientoDao.GuardarArchivo(estacionamiento);
            
            JOptionPane.showMessageDialog(null,"Datos Guardados Con Exito");
            Guardar.setText("Guardar");
            limpiar();
            activaDesactiva(false); 
 
         }
    }
    
    }//GEN-LAST:event_GuardarActionPerformed

    private void btn_ListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ListarActionPerformed
        JFrame frame =new Fm_ListaEstacionamiento();
        frame.setLocationRelativeTo(frame);
        frame.setVisible(true);
        this.hide();
    }//GEN-LAST:event_btn_ListarActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Fm_GuardarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Fm_GuardarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Fm_GuardarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Fm_GuardarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Fm_GuardarDatos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Color;
    private javax.swing.JLabel Fecha;
    private javax.swing.JButton Guardar;
    private javax.swing.JLabel Marca;
    private javax.swing.JLabel Matricula;
    private javax.swing.JLabel Modelo;
    private javax.swing.JButton Salir;
    private javax.swing.JButton btn_Listar;
    private javax.swing.JTextField txt_Color;
    private javax.swing.JTextField txt_Fecha;
    private javax.swing.JTextField txt_Marca;
    private javax.swing.JTextField txt_Matricula;
    private javax.swing.JTextField txt_Modelo;
    // End of variables declaration//GEN-END:variables
}
